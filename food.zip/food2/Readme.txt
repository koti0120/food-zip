Welcome to food website

this is after fist commit

this is added in branch feature1
